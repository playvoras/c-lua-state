# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 7.x.x   | :white_check_mark: |

## Reporting a Vulnerability

Users should send an email to bsergean@gmail.com to report a vulnerability.
